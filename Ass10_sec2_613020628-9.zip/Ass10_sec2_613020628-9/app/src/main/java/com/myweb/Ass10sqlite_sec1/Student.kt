package com.myweb.Ass10sqlite_sec1

data class Student (val id:String, val name: String, val age: Int){
}